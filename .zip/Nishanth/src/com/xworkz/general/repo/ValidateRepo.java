package com.xworkz.general.repo;

import com.xworkz.general.dto.RegisterDto;

public interface ValidateRepo {
    boolean save(RegisterDto registerDto);


}
