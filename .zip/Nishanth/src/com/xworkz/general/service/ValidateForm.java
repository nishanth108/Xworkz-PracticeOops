package com.xworkz.general.service;

import com.xworkz.general.dto.RegisterDto;

public interface ValidateForm {
    boolean save(RegisterDto registerDto);
}
